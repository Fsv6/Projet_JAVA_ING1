-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: triselectif
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bac`
--

DROP TABLE IF EXISTS `bac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bac` (
  `idBac` int NOT NULL,
  `poidsActuel` int DEFAULT NULL,
  `capaciteMax` int DEFAULT NULL,
  `typeDechet` varchar(50) DEFAULT NULL,
  `idPoubelleIntelligente` int NOT NULL,
  PRIMARY KEY (`idBac`),
  KEY `typeDechet` (`typeDechet`),
  KEY `idPoubelleIntelligente` (`idPoubelleIntelligente`),
  CONSTRAINT `bac_ibfk_1` FOREIGN KEY (`typeDechet`) REFERENCES `typedechet` (`typeDechet`),
  CONSTRAINT `bac_ibfk_2` FOREIGN KEY (`idPoubelleIntelligente`) REFERENCES `poubelleintelligente` (`idPoubelleIntelligente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bac`
--

LOCK TABLES `bac` WRITE;
/*!40000 ALTER TABLE `bac` DISABLE KEYS */;
/*!40000 ALTER TABLE `bac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bonachat`
--

DROP TABLE IF EXISTS `bonachat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bonachat` (
  `idBonAchat` int NOT NULL,
  `montant` int DEFAULT NULL,
  PRIMARY KEY (`idBonAchat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bonachat`
--

LOCK TABLES `bonachat` WRITE;
/*!40000 ALTER TABLE `bonachat` DISABLE KEYS */;
/*!40000 ALTER TABLE `bonachat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `centretri`
--

DROP TABLE IF EXISTS `centretri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `centretri` (
  `idCentreTri` int NOT NULL,
  `nomCentreTri` varchar(50) DEFAULT NULL,
  `numRue` int DEFAULT NULL,
  `nomRue` varchar(50) DEFAULT NULL,
  `ville` varchar(50) DEFAULT NULL,
  `codePostal` int DEFAULT NULL,
  PRIMARY KEY (`idCentreTri`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `centretri`
--

LOCK TABLES `centretri` WRITE;
/*!40000 ALTER TABLE `centretri` DISABLE KEYS */;
/*!40000 ALTER TABLE `centretri` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce`
--

DROP TABLE IF EXISTS `commerce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce` (
  `idCommerce` int NOT NULL,
  `nom` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idCommerce`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce`
--

LOCK TABLES `commerce` WRITE;
/*!40000 ALTER TABLE `commerce` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compte`
--

DROP TABLE IF EXISTS `compte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compte` (
  `idCompte` int NOT NULL,
  `nomResponsable` varchar(50) DEFAULT NULL,
  `prenomResponsable` varchar(50) DEFAULT NULL,
  `codeAcces` int DEFAULT NULL,
  `nbPointsFidelite` int DEFAULT NULL,
  PRIMARY KEY (`idCompte`),
  UNIQUE KEY `codeAcces` (`codeAcces`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compte`
--

LOCK TABLES `compte` WRITE;
/*!40000 ALTER TABLE `compte` DISABLE KEYS */;
/*!40000 ALTER TABLE `compte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contrat`
--

DROP TABLE IF EXISTS `contrat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contrat` (
  `idCentreTri` int NOT NULL,
  `idCommerce` int NOT NULL,
  `dateDebutContrat` date DEFAULT NULL,
  `dateFinContrat` date DEFAULT NULL,
  `listeCatProduits` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`idCentreTri`,`idCommerce`),
  KEY `idCommerce` (`idCommerce`),
  CONSTRAINT `contrat_ibfk_1` FOREIGN KEY (`idCentreTri`) REFERENCES `centretri` (`idCentreTri`),
  CONSTRAINT `contrat_ibfk_2` FOREIGN KEY (`idCommerce`) REFERENCES `commerce` (`idCommerce`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contrat`
--

LOCK TABLES `contrat` WRITE;
/*!40000 ALTER TABLE `contrat` DISABLE KEYS */;
/*!40000 ALTER TABLE `contrat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `convertir`
--

DROP TABLE IF EXISTS `convertir`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `convertir` (
  `idCompte` int NOT NULL,
  `idBonAchat` int NOT NULL,
  PRIMARY KEY (`idCompte`,`idBonAchat`),
  KEY `idBonAchat` (`idBonAchat`),
  CONSTRAINT `convertir_ibfk_1` FOREIGN KEY (`idCompte`) REFERENCES `compte` (`idCompte`),
  CONSTRAINT `convertir_ibfk_2` FOREIGN KEY (`idBonAchat`) REFERENCES `bonachat` (`idBonAchat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `convertir`
--

LOCK TABLES `convertir` WRITE;
/*!40000 ALTER TABLE `convertir` DISABLE KEYS */;
/*!40000 ALTER TABLE `convertir` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dechet`
--

DROP TABLE IF EXISTS `dechet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dechet` (
  `idDechet` int NOT NULL,
  `typeDechet` varchar(50) DEFAULT NULL,
  `poids` int DEFAULT NULL,
  `idDepot` int NOT NULL,
  PRIMARY KEY (`idDechet`),
  KEY `typeDechet` (`typeDechet`),
  KEY `idDepot` (`idDepot`),
  CONSTRAINT `dechet_ibfk_1` FOREIGN KEY (`typeDechet`) REFERENCES `typedechet` (`typeDechet`),
  CONSTRAINT `dechet_ibfk_2` FOREIGN KEY (`idDepot`) REFERENCES `depot` (`idDepot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dechet`
--

LOCK TABLES `dechet` WRITE;
/*!40000 ALTER TABLE `dechet` DISABLE KEYS */;
/*!40000 ALTER TABLE `dechet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `depot`
--

DROP TABLE IF EXISTS `depot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `depot` (
  `idDepot` int NOT NULL,
  `poidsDechet` int DEFAULT NULL,
  `pointsAttribues` int DEFAULT NULL,
  `dateDepot` date DEFAULT NULL,
  `idCompte` int NOT NULL,
  `idPoubelleIntelligente` int NOT NULL,
  PRIMARY KEY (`idDepot`),
  KEY `idCompte` (`idCompte`),
  KEY `idPoubelleIntelligente` (`idPoubelleIntelligente`),
  CONSTRAINT `depot_ibfk_1` FOREIGN KEY (`idCompte`) REFERENCES `compte` (`idCompte`),
  CONSTRAINT `depot_ibfk_2` FOREIGN KEY (`idPoubelleIntelligente`) REFERENCES `poubelleintelligente` (`idPoubelleIntelligente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `depot`
--

LOCK TABLES `depot` WRITE;
/*!40000 ALTER TABLE `depot` DISABLE KEYS */;
/*!40000 ALTER TABLE `depot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poubelleintelligente`
--

DROP TABLE IF EXISTS `poubelleintelligente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `poubelleintelligente` (
  `idPoubelleIntelligente` int NOT NULL,
  `nomQuartier` varchar(50) DEFAULT NULL,
  `longitudeEmplacement` decimal(8,6) DEFAULT NULL,
  `latitudeEmplacement` decimal(8,6) DEFAULT NULL,
  `idCentreTri` int NOT NULL,
  PRIMARY KEY (`idPoubelleIntelligente`),
  KEY `idCentreTri` (`idCentreTri`),
  CONSTRAINT `poubelleintelligente_ibfk_1` FOREIGN KEY (`idCentreTri`) REFERENCES `centretri` (`idCentreTri`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poubelleintelligente`
--

LOCK TABLES `poubelleintelligente` WRITE;
/*!40000 ALTER TABLE `poubelleintelligente` DISABLE KEYS */;
/*!40000 ALTER TABLE `poubelleintelligente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produit`
--

DROP TABLE IF EXISTS `produit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produit` (
  `idProduit` int NOT NULL,
  `nomProduit` varchar(50) DEFAULT NULL,
  `categorie` varchar(50) DEFAULT NULL,
  `prix` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`idProduit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produit`
--

LOCK TABLES `produit` WRITE;
/*!40000 ALTER TABLE `produit` DISABLE KEYS */;
/*!40000 ALTER TABLE `produit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `typedechet`
--

DROP TABLE IF EXISTS `typedechet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `typedechet` (
  `typeDechet` varchar(50) NOT NULL,
  PRIMARY KEY (`typeDechet`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typedechet`
--

LOCK TABLES `typedechet` WRITE;
/*!40000 ALTER TABLE `typedechet` DISABLE KEYS */;
/*!40000 ALTER TABLE `typedechet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utiliser`
--

DROP TABLE IF EXISTS `utiliser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `utiliser` (
  `idBonAchat` int NOT NULL,
  `idCommerce` int NOT NULL,
  PRIMARY KEY (`idBonAchat`,`idCommerce`),
  KEY `idCommerce` (`idCommerce`),
  CONSTRAINT `utiliser_ibfk_1` FOREIGN KEY (`idBonAchat`) REFERENCES `bonachat` (`idBonAchat`),
  CONSTRAINT `utiliser_ibfk_2` FOREIGN KEY (`idCommerce`) REFERENCES `commerce` (`idCommerce`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utiliser`
--

LOCK TABLES `utiliser` WRITE;
/*!40000 ALTER TABLE `utiliser` DISABLE KEYS */;
/*!40000 ALTER TABLE `utiliser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendre`
--

DROP TABLE IF EXISTS `vendre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vendre` (
  `idCommerce` int NOT NULL,
  `idProduit` int NOT NULL,
  PRIMARY KEY (`idCommerce`,`idProduit`),
  KEY `idProduit` (`idProduit`),
  CONSTRAINT `vendre_ibfk_1` FOREIGN KEY (`idCommerce`) REFERENCES `commerce` (`idCommerce`),
  CONSTRAINT `vendre_ibfk_2` FOREIGN KEY (`idProduit`) REFERENCES `produit` (`idProduit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendre`
--

LOCK TABLES `vendre` WRITE;
/*!40000 ALTER TABLE `vendre` DISABLE KEYS */;
/*!40000 ALTER TABLE `vendre` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-27 15:07:44
