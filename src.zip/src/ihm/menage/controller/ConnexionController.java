package ihm.menage.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Parent;

public class ConnexionController {

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    // Méthode appelée lors du clic sur "Se connecter"
    @FXML
    private void handleLogin(ActionEvent event) {
        String email = emailField.getText();
        String password = passwordField.getText();

        if (email.isEmpty() || password.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Champs manquants", "Veuillez remplir tous les champs.");
            return;
        }

        try {
            String fxmlToLoad = null;

            // Logins de test en dur
            if (email.equals("menage@test.com") && password.equals("1234")) {
                fxmlToLoad = "/ihm/menage/view/ProfilGeneral.fxml";
            } else if (email.equals("centre@test.com") && password.equals("1234")) {
                fxmlToLoad = "/ihm/centreTri/view/accueil.fxml";
            } else if (email.equals("commerce@test.com") && password.equals("1234")) {
                fxmlToLoad = "/ihm/commerce/view/CommerceLayout.fxml";
            } else {
                showAlert(Alert.AlertType.ERROR, "Échec de la connexion", "Identifiants incorrects.");
                return;
            }

            // Charger la bonne vue FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlToLoad));
            Parent root = loader.load();

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de charger l'interface.");
        }
    }

    @FXML
    private void handleSignUp(ActionEvent event) {
        showAlert(Alert.AlertType.INFORMATION, "Redirection", "Fonction d'inscription non implémentée.");
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}


