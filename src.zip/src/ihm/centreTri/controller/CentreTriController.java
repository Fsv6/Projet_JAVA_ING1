package ihm.centreTri.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import src.tri.logic.*;
import src.tri.dao.*;
import java.util.List;
import javafx.event.ActionEvent;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class CentreTriController {

    // === BOUTONS PRINCIPAUX ===
    @FXML private Button deconnexion;
    @FXML private Button placerpoubelles;
    @FXML private Button créer_contrat;
    @FXML private Button stats;
    @FXML private Button poubellePleine;
    @FXML private Button btnRenouveler; // Correspond au fx:id dans votre FXML

    // === FORMULAIRES ===
    @FXML private VBox formPlacerPoubelle;
    @FXML private VBox formContrat;
    @FXML private VBox formStats;

    // === CHAMPS FORMULAIRES ===
    @FXML private TextField latitude;
    @FXML private TextField longitude;
    @FXML private TextField nomQuartier;
    @FXML private TextField nomCommerce;
    @FXML private DatePicker dateDebut;
    @FXML private DatePicker dateFin;
    @FXML private TextField fieldIdCentreTri;
    @FXML private TextField fieldIdCommerce;
    @FXML private DatePicker dateDebutContrat;
    @FXML private DatePicker dateFinContrat;
    @FXML private CheckBox catAlimentaire;
    @FXML private CheckBox catVetements;
    @FXML private CheckBox catElectronique;
    @FXML private CheckBox catCosmetiques;
    @FXML private CheckBox catMeubles;
    @FXML private CheckBox catJouets;
    @FXML private CheckBox catLivres;


    // === ZONE D'INFORMATION ===
    @FXML private TextArea zoneInfo;
    @FXML private TextArea statsArea;

    // === CONTENEURS DYNAMIQUES ===
    @FXML private VBox listePoubellesContainer;
    @FXML private VBox listeContratsContainer;

    // === DAO / LISTES ===
    private final PoubelleIntelligenteDAO poubelleDAO = new PoubelleIntelligenteDAO();
    private final ContratDAO contratDAO = new ContratDAO();
    private final BacDAO bacDAO = new BacDAO();
    private final CentreTriDAO centreTriDAO = new CentreTriDAO();
    private final CommerceDAO commerceDAO = new CommerceDAO();
    private List<PoubelleIntelligente> poubelles = new ArrayList<>();

    // === INITIALISATION ===
 // Méthode pour initialiser l'interface
    @FXML
    private void initialize() {
        // Par exemple, initialiser avec une date d'expiration fictive
        LocalDate dateExpiration = LocalDate.of(2025, 5, 10); // Remplacez par la date réelle de votre contrat

        // Vérifiez si le contrat est expiré et mettez à jour le bouton
        if (estContratExpire(dateExpiration)) {
            // Si le contrat est expiré, rendez le bouton "Renouveler" rouge
            btnRenouveler.setStyle("-fx-background-color: red; -fx-text-fill: white;");
        } else {
            // Si le contrat n'est pas expiré, rendez le bouton "Renouveler" grisé
            btnRenouveler.setStyle("-fx-background-color: gray; -fx-text-fill: white;");
        }
    }
    // === GESTION DE L'AFFICHAGE ===
    private void cacherTousLesPanneaux() {
        formPlacerPoubelle.setVisible(false);  // Masque le formulaire de placer une poubelle
        formContrat.setVisible(false);  // Masque le formulaire de création de contrat
        listePoubellesContainer.setVisible(false);  // Masque la liste des poubelles
        listeContratsContainer.setVisible(false);  // Masque la liste des contrats
        formStats.setVisible(false);  // Masque le formulaire de statistiques
    }


    // === ACTIONS DES BOUTONS ===
    @FXML
    private void handleDeconnexion(ActionEvent event) {
        try {
            // Charger la vue de connexion
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ihm/menage/view/ConnexionOverview.fxml"));
            Parent root = loader.load();

            // Créer une nouvelle scène
            Stage stageConnexion = new Stage();
            stageConnexion.setTitle("Connexion");
            stageConnexion.setScene(new Scene(root));
            stageConnexion.show();

            // Fermer la fenêtre actuelle
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            currentStage.close();

        } catch (IOException e) {
            e.printStackTrace();
            // Log en cas d'erreur
        }
    }


    @FXML
    private void handlePlacerPoubelle() {
        cacherTousLesPanneaux();
        formPlacerPoubelle.setVisible(true);
        zoneInfo.clear();
    }
    
    @FXML
    private void handleAfficherFormContrat() {
        formContrat.setVisible(true);

        // Cacher les autres vues
        formPlacerPoubelle.setVisible(false);
        formStats.setVisible(false);
        listePoubellesContainer.setVisible(false);
        listeContratsContainer.setVisible(false);
    }

    @FXML
    private void handleCreerContrat() {
        try {
            int idCentreTri = centreTriDAO.getUniqueCentreTriId();
            String commerceText = fieldIdCommerce.getText().trim();

            if (commerceText.isEmpty()) {
                zoneInfo.setText("Veuillez renseigner l’ID du commerce.");
                return;
            }

            if (!commerceText.matches("\\d+")) {
                zoneInfo.setText("Erreur : l’ID du commerce doit être un entier positif.");
                return;
            }

            int idCommerce = Integer.parseInt(commerceText);
            LocalDate dateDebut = dateDebutContrat.getValue();
            LocalDate dateFin = dateFinContrat.getValue();

            if (dateDebut == null || dateFin == null || dateFin.isBefore(dateDebut)) {
                zoneInfo.setText("Erreur : dates invalides (début ou fin manquante ou incohérente).");
                return;
            }

            List<String> categories = new ArrayList<>();
            if (catAlimentaire.isSelected()) categories.add("Alimentaire");
            if (catCosmetiques.isSelected()) categories.add("Cosmétiques");
            if (catVetements.isSelected()) categories.add("Vêtements");
            if (catElectronique.isSelected()) categories.add("Électronique");
            if (catMeubles.isSelected()) categories.add("Meubles");
            if (catJouets.isSelected()) categories.add("Jouets");
            if (catLivres.isSelected()) categories.add("Livres");

            if (categories.isEmpty()) {
                zoneInfo.setText("Veuillez sélectionner au moins une catégorie de produits.");
                return;
            }

            Contrat contrat = new Contrat(idCentreTri, dateDebut, dateFin, categories);
            contratDAO.insertContrat(contrat, idCentreTri, idCommerce);

            zoneInfo.setText("Contrat créé avec succès !");
            formContrat.setVisible(false);

        } catch (Exception e) {
            zoneInfo.setText("Erreur lors de la création du contrat : " + e.getMessage());
        }
    }




    @FXML
    private void handleListePoubelles() {
        cacherTousLesPanneaux();
        chargerListePoubelles();
        listePoubellesContainer.setVisible(true);
        zoneInfo.setText("Liste des poubelles chargée.");
    }
    
    // Méthode d'action pour le bouton "Renouveler"
    @FXML
    private void handleRenouvelerContrat() {
        // Logique pour renouveler le contrat
        System.out.println("Le contrat a été renouvelé !");
    }
    
 // Méthode pour vérifier si le contrat est expiré
    private boolean estContratExpire(LocalDate dateExpiration) {
        LocalDate today = LocalDate.now();
        return dateExpiration.isBefore(today); // Si la date d'expiration est avant aujourd'hui, le contrat est expiré
    }

    @FXML
    private void handleListeContrats() {
        cacherTousLesPanneaux();
        chargerListeContrats();
        listeContratsContainer.setVisible(true);
        zoneInfo.setText("Liste des contrats chargée.");
    }

    // === FORMULAIRES ===
    @FXML
    private void handleValiderPoubelle() {
        try {
            String nomQuartierText = nomQuartier.getText();
            String latitudeText = latitude.getText();
            String longitudeText = longitude.getText();

            if (nomQuartierText.isEmpty() || latitudeText.isEmpty() || longitudeText.isEmpty()) {
                zoneInfo.setText("Veuillez remplir tous les champs.");
                return;
            }

            float latitudeValue = Float.parseFloat(latitudeText);
            float longitudeValue = Float.parseFloat(longitudeText);

            // Créer une poubelle sans ID (généré par MySQL)
            PoubelleIntelligente poubelle = new PoubelleIntelligente(nomQuartierText, latitudeValue, longitudeValue);

            // 1. Insérer la poubelle et récupérer l’ID généré
            int idCentreTri = centreTriDAO.getUniqueCentreTriId(); 
            poubelleDAO.insertPoubelle(poubelle, idCentreTri); // ID affecté à poubelle automatiquement

            int idPoubelleGenere = poubelle.getId(); // maintenant connu

            // 2. Créer les 4 bacs associés à cette poubelle
            BacDAO bacDAO = new BacDAO();      
            List<List<TypeDechet>> typeParBac = Arrays.asList(
            	    Collections.singletonList(TypeDechet.VERRE),
            	    Arrays.asList(TypeDechet.METAL, TypeDechet.CARTON, TypeDechet.PLASTIQUE),
            	    Collections.singletonList(TypeDechet.PAPIER),
            	    Collections.singletonList(TypeDechet.AUTRE)
            	);

            	for (List<TypeDechet> typesPourBac : typeParBac) {
            	    Bac bac = new Bac(100, typesPourBac);
            	    bacDAO.insertBac(bac, idPoubelleGenere);
            	}


            // Message de succès
            zoneInfo.setText("Poubelle ajoutée avec succès (ID auto : " + idPoubelleGenere + ") et bacs associés.");

            // Réinitialisation des champs
            nomQuartier.clear();
            latitude.clear();
            longitude.clear();

            formPlacerPoubelle.setVisible(false);

        } catch (NumberFormatException e) {
            zoneInfo.setText("Erreur : veuillez entrer des nombres valides pour la latitude et la longitude.");
        } catch (Exception e) {
            zoneInfo.setText("Erreur lors de l'ajout de la poubelle : " + e.getMessage());
        }
    }



    @FXML
    private void handleValiderContrat() {
        String commerce = nomCommerce.getText();
        var debut = dateDebut.getValue();
        var fin = dateFin.getValue();

        if (commerce.isEmpty() || debut == null || fin == null) {
            zoneInfo.setText("Veuillez remplir tous les champs du contrat.");
            return;
        }
        
     // Vérifier que la date de début n'est pas dans le passé
        if (debut.isBefore(LocalDate.now())) {
            zoneInfo.setText("La date de début ne peut pas être antérieure à aujourd'hui.");
            return;
        }

        // Vérifier que la date de fin est après la date de début
        if (fin.isBefore(debut)) {
            zoneInfo.setText("La date de fin doit être postérieure à la date de début.");
            return;
        }

        // Enregistrer le contrat (ajoute logique ici)
        zoneInfo.setText("Contrat créé pour '" + commerce + "' du " + debut + " au " + fin);
        nomCommerce.clear();
        dateDebut.setValue(null);
        dateFin.setValue(null);
        formContrat.setVisible(false);
    }
    
    @FXML
    private void handleAfficherStats() {
        cacherTousLesPanneaux();  // Masque les autres panneaux
        formStats.setVisible(true);  // Affiche la section des statistiques
        statsArea.setText("Chargement des statistiques...\n\n");

        // Récupérer la liste des poubelles et des contrats
        List<PoubelleIntelligente> poubelles = poubelleDAO.getAllPoubelles();
        List<Contrat> contrats = contratDAO.getAllContrats();

        // Calculer le nombre total de poubelles
        int totalPoubelles = poubelles.size();

        // Calculer le nombre de poubelles pleines
        /*long poubellesPleinCount = poubelles.stream().filter(PoubelleIntelligente::estPleine).count();

        // Calculer le pourcentage de poubelles pleines
        double pourcentagePoubellesPleine = totalPoubelles > 0 ? (double) poubellesPleinCount / totalPoubelles * 100 : 0;

        */

        // Afficher les résultats dans le TextArea
        String statistiques = "Statistiques du Centre de Tri\n\n";
        statistiques += "Nombre total de poubelles : " + totalPoubelles + "\n";
        //statistiques += "Pourcentage de poubelles pleines : " + String.format("%.2f", pourcentagePoubellesPleine) + "%\n";
        

        statsArea.setText(statistiques);
    }


    // === AFFICHAGE DYNAMIQUE ===
    private void chargerListePoubelles() {
        listePoubellesContainer.getChildren().clear();
        List<PoubelleIntelligente> poubelles = poubelleDAO.getAllPoubelles();
        System.out.println("Nombre de poubelles récupérées : " + poubelles.size());
        for (PoubelleIntelligente p : poubelles) {
            VBox vbox = new VBox(5);
            vbox.setStyle("-fx-padding: 10; -fx-background-color: #ecf0f1;");

            Label label = new Label("Poubelle: " + p.getNomQuartier());

            Button supprimer = new Button("Supprimer");
            supprimer.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
            supprimer.setOnAction(e -> supprimerPoubelle(p));

            Button vider = new Button("Vider");
         // Style par défaut : gris et désactivé
            vider.setStyle("-fx-background-color: grey; -fx-text-fill: white;");
            vider.setDisable(true); // désactivé
            
         // Mettons à jour dynamiquement selon l'état de la poubelle
            if (p.estPleine()) {
                vider.setDisable(false); // bouton activé
                vider.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;"); // bleu
             // Ajouter l'action pour vider la poubelle
                vider.setOnAction(e -> viderPoubelle(p));
            } else {
                vider.setDisable(true); // bouton désactivé
                vider.setStyle("-fx-background-color: grey; -fx-text-fill: white;"); // gris
            }

            vbox.getChildren().addAll(label, supprimer, vider);
            listePoubellesContainer.getChildren().add(vbox);
        }
    }


    private void chargerListeContrats() {
        listeContratsContainer.getChildren().clear();

        int idCentreTri = centreTriDAO.getUniqueCentreTriId(); // récupération dynamique
        List<Integer> idsCommerce = commerceDAO.getAllCommerceIds(); // méthode à avoir dans CommerceDAO

        for (int idCommerce : idsCommerce) {
            try {
                Contrat contrat = contratDAO.getContrat(idCentreTri, idCommerce);

                VBox vbox = new VBox(5);
                vbox.setStyle("-fx-padding: 10; -fx-background-color: #ecf0f1;");

                Label label = new Label("Contrat avec commerce #" + idCommerce +
                                        " du " + contrat.getDateDebut() +
                                        " au " + contrat.getDateFin());

                Button supprimer = new Button("Supprimer");
                supprimer.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
                supprimer.setOnAction(e -> supprimerContrat(contrat, idCentreTri, idCommerce));

                vbox.getChildren().addAll(label, supprimer);
                listeContratsContainer.getChildren().add(vbox);

            } catch (RuntimeException e) {
                // Aucun contrat pour ce commerce : on ignore (ou log optionnel)
            }
        }
    }


   

    // === ACTIONS SPÉCIFIQUES ===
    private void viderPoubelle(PoubelleIntelligente p) {
        float poidsTotal = 0;

        System.out.println("=== Vidage de la poubelle ID: " + p.getId() + " ===");
        System.out.println("Liste des bacs associés :");

        for (Bac bac : p.getBacs()) {
            System.out.println(" - Bac ID: " + bac.getIdBac() + ", poids: " + bac.getPoidsActuel() + " kg");
            poidsTotal += bac.getPoidsActuel(); // cumul du poids de chaque bac
            //p.vider();
            bacDAO.viderBac(bac.getIdBac()); // en base
        }

        
        chargerListePoubelles(); // rafraîchir l'IHM

        String message = "Poubelle #" + p.getId() + " vidée. Poids total avant vidage : " + poidsTotal + " kg.";
        System.out.println(message); // log console
        zoneInfo.setText(message);   // log IHM
    }


    private void supprimerPoubelle(PoubelleIntelligente p) {
        try {
            poubelleDAO.deletePoubelle(p.getId());
            chargerListePoubelles(); // Refresh
            zoneInfo.setText("Poubelle supprimée.");
        } catch (Exception e) {
            zoneInfo.setText("Erreur suppression : " + e.getMessage());
        }
    }

    private void supprimerContrat(Contrat contrat, int idCentreTri, int idCommerce) {
        try {
            contratDAO.deleteContrat(idCentreTri, idCommerce);
            chargerListeContrats();
            zoneInfo.setText("Contrat supprimé avec commerce #" + idCommerce);
        } catch (Exception e) {
            zoneInfo.setText("Erreur suppression contrat : " + e.getMessage());
        }
    }

    @FXML private TextField fieldIdCommerceSuppression;

    @FXML
    private void handleSupprimerContratManuellement() {
        try {
            int idCentreTri = centreTriDAO.getUniqueCentreTriId();
            int idCommerce = Integer.parseInt(fieldIdCommerceSuppression.getText());

            contratDAO.deleteContrat(idCentreTri, idCommerce);
            chargerListeContrats();
            zoneInfo.setText("Contrat supprimé avec le commerce #" + idCommerce);

        } catch (NumberFormatException e) {
            zoneInfo.setText("Entrée invalide : veuillez entrer un ID numérique.");
        } catch (Exception e) {
            zoneInfo.setText("Erreur lors de la suppression du contrat : " + e.getMessage());
        }
    }


    
}
