package src.tri.logic;

public enum TypeDechet {
	CARTON, VERRE, METAL, PAPIER, PLASTIQUE, AUTRE
}
