package src.tri.logic;

public class BonAchat {

    private int id;
    private int montant;


    public BonAchat(int id, int montant) {
        this.id = id;
        this.montant = montant;
    }
    
    public BonAchat(int montant) {
        this.montant = montant;
    }

    public int getId() {
        return id;
    }
    
    public void setId(int id) {
    	this.id = id;
    }
 
    public int getMontant() {
        return montant;
    }

    @Override
    public String toString() {
        return "BonAchat{id=" + id + ", montant=" + montant + "}";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof BonAchat)) return false;
        BonAchat other = (BonAchat) obj;
        return this.id == other.id;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }
}

