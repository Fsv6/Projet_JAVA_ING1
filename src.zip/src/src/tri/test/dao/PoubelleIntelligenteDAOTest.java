package src.tri.test.dao;

import src.tri.dao.PoubelleIntelligenteDAO;
import src.tri.logic.PoubelleIntelligente;

public class PoubelleIntelligenteDAOTest {

    public static void main(String[] args) {
        PoubelleIntelligenteDAO dao = new PoubelleIntelligenteDAO();

        int idCentreTriExistant = 1; // À adapter selon ton jeu de données

        System.out.println("---- Insertion d'une poubelle ----");
        PoubelleIntelligente poubelle = new PoubelleIntelligente("Quartier Nord", 48.85f, 2.35f);
        dao.insertPoubelle(poubelle, idCentreTriExistant);
        System.out.println("Poubelle insérée avec ID : " + poubelle.getId());

        System.out.println("\n---- Récupération par ID ----");
        PoubelleIntelligente p1 = dao.getPoubelleById(poubelle.getId());
        System.out.println("Nom quartier : " + p1.getNomQuartier() + ", Latitude : " + p1.getLatitudeEmplacement());

        System.out.println("\n---- Vérification du cache ----");
        PoubelleIntelligente p2 = dao.getPoubelleById(poubelle.getId());
        System.out.println("Même instance en mémoire ? " + (p1 == p2));

        System.out.println("\n---- Suppression de la poubelle ----");
        dao.deletePoubelle(poubelle.getId());
        System.out.println("Poubelle supprimée.");

        System.out.println("\n---- Vérification après suppression ----");
        try {
            dao.getPoubelleById(poubelle.getId());
            System.out.println("ERREUR : poubelle encore récupérable !");
        } catch (RuntimeException e) {
            System.out.println("OK : poubelle introuvable après suppression : " + e.getMessage());
        }

        System.out.println("\n---- Fin du test PoubelleIntelligenteDAO ----");
    }
}

