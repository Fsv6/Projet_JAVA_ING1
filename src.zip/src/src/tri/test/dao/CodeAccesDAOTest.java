package src.tri.test.dao;

import src.tri.dao.CodeAccesDAO;

public class CodeAccesDAOTest {

    public static void main(String[] args) {
        CodeAccesDAO dao = new CodeAccesDAO();
        int idPoubelle = 1; // à adapter selon une ID existante dans ta base
        String codeInitial = "ABC123";
        String nouveauCode = "XYZ789";

        System.out.println("---- Insertion d'un code d'accès ----");
        dao.insertCodeAcces(codeInitial, idPoubelle);
        System.out.println("Code inséré pour poubelle ID " + idPoubelle);

        System.out.println("\n---- Vérification du code ----");
        boolean existe = dao.verifierCodeAcces(codeInitial);
        System.out.println("Code " + codeInitial + " existe ? " + existe);

        System.out.println("\n---- Récupération de l'ID de la poubelle par code ----");
        int idTrouvé = dao.getIdPoubelleByCode(codeInitial);
        System.out.println("ID récupéré pour le code : " + idTrouvé);

        System.out.println("\n---- Mise à jour du code d'accès ----");
        dao.updateCodeAcces(idPoubelle, nouveauCode);
        System.out.println("Code mis à jour pour ID " + idPoubelle);

        System.out.println("\n---- Vérification du nouveau code ----");
        boolean nouveauExiste = dao.verifierCodeAcces(nouveauCode);
        System.out.println("Code " + nouveauCode + " existe ? " + nouveauExiste);

        System.out.println("\n---- Suppression du code d'accès ----");
        dao.deleteCodeAcces(idPoubelle);
        System.out.println("Code supprimé pour ID " + idPoubelle);

        System.out.println("\n---- Vérification après suppression ----");
        boolean existeEncore = dao.verifierCodeAcces(nouveauCode);
        System.out.println("Code encore présent ? " + existeEncore);

        System.out.println("\n---- Fin du test CodeAccesDAO ----");
    }
}

