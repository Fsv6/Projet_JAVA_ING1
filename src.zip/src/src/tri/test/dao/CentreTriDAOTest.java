package src.tri.test.dao;

import src.tri.dao.CentreTriDAO;
import src.tri.logic.CentreTri;

public class CentreTriDAOTest {

    public static void main(String[] args) {
        CentreTriDAO dao = new CentreTriDAO();

        System.out.println("---- Insertion du centre de tri ----");
        CentreTri centre = new CentreTri("Centre Principal", 12, "Rue du Recyclage", "Recyville", 75000);
        dao.insertCentreTri(centre);
        System.out.println("Centre inséré avec ID : " + centre.getIdCentreTri());

        System.out.println("\n---- Récupération du centre (depuis la base ou cache) ----");
        CentreTri centre1 = dao.getUniqueCentreTri();
        System.out.println("Nom récupéré : " + centre1.getNomCentreTri());

        System.out.println("\n---- Vérification du cache ----");
        CentreTri centre2 = dao.getUniqueCentreTri();
        System.out.println("Même instance en mémoire ? " + (centre1 == centre2));


        System.out.println("\n---- Fin du test CentreTriDAO ----");
    }
}
