package src.tri.test.dao;

import src.tri.dao.DechetDAO;
import src.tri.logic.Dechet;
import src.tri.logic.TypeDechet;

import java.util.List;

public class DechetDAOTest {

    public static void main(String[] args) {
        DechetDAO dao = new DechetDAO();

        int idDepotExistant = 1; // À adapter si besoin

        System.out.println("---- Insertion d'un déchet ----");
        Dechet dechet = new Dechet(TypeDechet.PLASTIQUE, 12);
        dao.insertDechet(dechet, idDepotExistant);
        System.out.println("Déchet inséré avec ID : " + dechet.getIdDechet());

        System.out.println("\n---- Récupération par ID ----");
        Dechet d1 = dao.getDechetById(dechet.getIdDechet());
        System.out.println("Type : " + d1.getType() + ", poids : " + d1.getPoids());

        System.out.println("\n---- Vérification du cache ----");
        Dechet d2 = dao.getDechetById(dechet.getIdDechet());
        System.out.println("Même instance en mémoire ? " + (d1 == d2));

        System.out.println("\n---- Récupération des déchets par dépôt ----");
        List<Dechet> liste = dao.getDechetsByDepot(idDepotExistant);
        System.out.println("Déchets associés à ce dépôt : " + liste.size());

        System.out.println("\n---- Suppression du déchet ----");
        dao.deleteDechet(dechet.getIdDechet());
        System.out.println("Déchet supprimé.");

        System.out.println("\n---- Vérification après suppression ----");
        try {
            dao.getDechetById(dechet.getIdDechet());
            System.out.println("ERREUR : déchet encore récupérable !");
        } catch (RuntimeException e) {
            System.out.println("OK : déchet introuvable après suppression : " + e.getMessage());
        }

        System.out.println("\n---- Fin du test DechetDAO ----");
    }
}


