package src.tri.test.dao;

import src.tri.dao.BonAchatDAO;
import src.tri.logic.BonAchat;

public class BonAchatDAOTest {

    public static void main(String[] args) {
        BonAchatDAO dao = new BonAchatDAO();

        System.out.println("---- Insertion d'un bon d'achat ----");
        BonAchat bon = new BonAchat(500); // suppose un constructeur BonAchat(int montant)
        dao.insertBonAchat(bon);
        System.out.println("Bon inséré avec ID : " + bon.getId());

        System.out.println("\n---- Récupération depuis la base/cache ----");
        BonAchat bonFromDb = dao.getBonAchatById(bon.getId());
        System.out.println("Bon récupéré : montant = " + bonFromDb.getMontant());

        System.out.println("\n---- Vérification du cache ----");
        BonAchat bonFromCache = dao.getBonAchatById(bon.getId());
        System.out.println("Même instance ? " + (bonFromDb == bonFromCache));

        System.out.println("\n---- Suppression du bon ----");
        dao.deleteBonAchat(bon.getId());

        System.out.println("\n---- Tentative de récupération après suppression ----");
        try {
            dao.getBonAchatById(bon.getId());
            System.out.println("ERREUR : le bon est toujours accessible !");
        } catch (RuntimeException e) {
            System.out.println("OK : bon introuvable après suppression : " + e.getMessage());
        }

        System.out.println("\n---- Fin du test BonAchatDAO ----");
    }
}
