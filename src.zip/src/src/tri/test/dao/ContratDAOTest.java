package src.tri.test.dao;

import src.tri.dao.ContratDAO;
import src.tri.logic.Contrat;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

public class ContratDAOTest {

    public static void main(String[] args) {
        ContratDAO dao = new ContratDAO();

        int idCentreTri = 1;     // à adapter selon ta base
        int idCommerce = 1;      // idem

        List<String> produits = Arrays.asList("Plastique", "Papier", "Verre");
        Contrat contrat = new Contrat(LocalDate.now(), LocalDate.now().plusMonths(6), produits);

        System.out.println("---- Insertion d'un contrat ----");
        dao.insertContrat(contrat, idCentreTri, idCommerce);
        System.out.println("Contrat inséré avec ID : " + contrat.getId());

        System.out.println("\n---- Récupération du contrat ----");
        Contrat c1 = dao.getContrat(idCentreTri, idCommerce);
        System.out.println("Début : " + c1.getDateDebut() + ", Fin : " + c1.getDateFin());

        System.out.println("\n---- Vérification du cache ----");
        Contrat c2 = dao.getContrat(idCentreTri, idCommerce);
        System.out.println("Même instance en mémoire ? " + (c1 == c2));

        System.out.println("\n---- Suppression du contrat ----");
        dao.deleteContrat(idCentreTri, idCommerce);
        System.out.println("Contrat supprimé.");

        System.out.println("\n---- Vérification après suppression ----");
        try {
            dao.getContrat(idCentreTri, idCommerce);
            System.out.println("ERREUR : contrat encore récupérable !");
        } catch (RuntimeException e) {
            System.out.println("OK : contrat introuvable après suppression : " + e.getMessage());
        }

        System.out.println("\n---- Fin du test ContratDAO ----");
    }
}
