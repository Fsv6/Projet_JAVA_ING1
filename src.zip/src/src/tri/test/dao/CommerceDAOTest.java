package src.tri.test.dao;

import src.tri.dao.CommerceDAO;
import src.tri.logic.Commerce;

public class CommerceDAOTest {

    public static void main(String[] args) {
        CommerceDAO dao = new CommerceDAO();

        System.out.println("---- Insertion d'un commerce ----");
        Commerce commerce = new Commerce("Biocoop");
        dao.insertCommerce(commerce);
        System.out.println("Commerce inséré avec ID : " + commerce.getIdCommerce());

        System.out.println("\n---- Récupération du commerce depuis la base/cache ----");
        Commerce commerce1 = dao.getCommerceById(commerce.getIdCommerce());
        System.out.println("Nom récupéré : " + commerce1.getNom());

        System.out.println("\n---- Vérification du cache ----");
        Commerce commerce2 = dao.getCommerceById(commerce.getIdCommerce());
        System.out.println("Même instance en mémoire ? " + (commerce1 == commerce2));

        System.out.println("\n---- Suppression du commerce ----");
        dao.deleteCommerce(commerce.getIdCommerce());

        System.out.println("\n---- Tentative de récupération après suppression ----");
        try {
            dao.getCommerceById(commerce.getIdCommerce());
            System.out.println("ERREUR : commerce encore récupérable après suppression !");
        } catch (RuntimeException e) {
            System.out.println("OK : commerce introuvable après suppression : " + e.getMessage());
        }

        System.out.println("\n---- Fin du test CommerceDAO ----");
    }
}
