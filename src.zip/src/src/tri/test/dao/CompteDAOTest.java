package src.tri.test.dao;

import src.tri.dao.CompteDAO;
import src.tri.logic.Compte;

public class CompteDAOTest {

    public static void main(String[] args) {
        CompteDAO compteDAO = new CompteDAO();

        System.out.println("---- Création d'un nouveau compte ----");
        Compte nouveauCompte = new Compte("Martin", "Paul", 100);
        compteDAO.insertCompte(nouveauCompte);
        System.out.println("Compte inséré avec ID : " + nouveauCompte.getId());

        System.out.println("\n---- Récupération du compte (depuis la base/cache) ----");
        Compte compteFromDb = compteDAO.getCompteById(nouveauCompte.getId());
        System.out.println("Compte récupéré : " + compteFromDb);

        System.out.println("\n---- Vérification du cache (réutilisation d'objet) ----");
        Compte compteFromCache = compteDAO.getCompteById(nouveauCompte.getId());
        System.out.println("Référence identique ? " + (compteFromDb == compteFromCache));

        System.out.println("\n---- Mise à jour des points de fidélité ----");
        compteDAO.updatePointsFidelite(nouveauCompte.getId(), 250);
        Compte updatedCompte = compteDAO.getCompteById(nouveauCompte.getId());
        System.out.println("Points après update : " + updatedCompte.getNbPointsFidelite());

        System.out.println("\n---- Suppression du compte ----");
        compteDAO.deleteCompte(nouveauCompte.getId());

        System.out.println("\n---- Tentative de récupération après suppression ----");
        try {
            compteDAO.getCompteById(nouveauCompte.getId());
            System.out.println("ERREUR : Compte encore récupérable après suppression !");
        } catch (RuntimeException e) {
            System.out.println("OK : Compte introuvable (comme attendu) : " + e.getMessage());
        }

        System.out.println("\n---- Fin des tests ----");
    }
}
