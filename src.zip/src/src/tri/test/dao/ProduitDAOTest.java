package src.tri.test.dao;

import src.tri.dao.ProduitDAO;
import src.tri.logic.Produit;

public class ProduitDAOTest {

    public static void main(String[] args) {
        ProduitDAO dao = new ProduitDAO();

        System.out.println("---- Insertion d’un produit ----");
        Produit produit = new Produit("Alimentaire", "Pâtes Bio", 4.50);
        dao.insertProduit(produit);
        System.out.println("Produit inséré avec ID : " + produit.getIdProduit());

        System.out.println("\n---- Récupération du produit ----");
        Produit p1 = dao.getProduitById(produit.getIdProduit());
        System.out.println("Nom : " + p1.getNom() + ", Catégorie : " + p1.getCategorie() + ", Prix : " + p1.getPrix());

        System.out.println("\n---- Vérification du cache ----");
        Produit p2 = dao.getProduitById(produit.getIdProduit());
        System.out.println("Même instance en mémoire ? " + (p1 == p2));

        System.out.println("\n---- Suppression du produit ----");
        dao.deleteProduit(produit.getIdProduit());
        System.out.println("Produit supprimé.");

        System.out.println("\n---- Vérification après suppression ----");
        try {
            dao.getProduitById(produit.getIdProduit());
            System.out.println("ERREUR : produit encore récupérable !");
        } catch (RuntimeException e) {
            System.out.println("OK : produit introuvable après suppression : " + e.getMessage());
        }

        System.out.println("\n---- Fin du test ProduitDAO ----");
    }
}

