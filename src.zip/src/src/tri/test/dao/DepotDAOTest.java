package src.tri.test.dao;

import src.tri.dao.DepotDAO;
import src.tri.logic.Depot;
import src.tri.logic.TypeDechet;
import src.tri.logic.Dechet;

import java.util.ArrayList;
import java.util.Date;

public class DepotDAOTest {

    public static void main(String[] args) {
        DepotDAO dao = new DepotDAO();

        System.out.println("---- Insertion d'un dépôt ----");
        ArrayList<Dechet> dechets = new ArrayList<>();
        dechets.add(new Dechet(TypeDechet.METAL, 10)); // suppose un constructeur Dechet(int poids)
        dechets.add(new Dechet(TypeDechet.METAL, 5));

        Depot depot = new Depot(20, new Date(), dechets); // 20 points attribués
        dao.insertDepot(depot, 1, 1); // compte ID 1, poubelle ID 1 à adapter
        System.out.println("Dépôt inséré avec ID : " + depot.getIdDepot());

        System.out.println("\n---- Récupération du dépôt depuis la base/cache ----");
        Depot depotFromDb = dao.getDepotById(depot.getIdDepot());
        System.out.println("Points attribués : " + depotFromDb.getPointsAttribues());
        System.out.println("Date : " + depotFromDb.getDateDepot());

        System.out.println("\n---- Vérification du cache ----");
        Depot depotFromCache = dao.getDepotById(depot.getIdDepot());
        System.out.println("Même instance en mémoire ? " + (depotFromDb == depotFromCache));

        System.out.println("\n---- Suppression du dépôt ----");
        dao.deleteDepot(depot.getIdDepot());
        System.out.println("Dépôt supprimé.");

        System.out.println("\n---- Tentative de récupération après suppression ----");
        try {
            dao.getDepotById(depot.getIdDepot());
            System.out.println("ERREUR : dépôt encore récupérable après suppression !");
        } catch (RuntimeException e) {
            System.out.println("OK : dépôt introuvable après suppression : " + e.getMessage());
        }

        System.out.println("\n---- Fin du test DepotDAO ----");
    }
}

