package src.tri.dao;

import src.tri.utils.DatabaseConnection;
import java.sql.*;

public class CodeAccesDAO {

    public void insertCodeAcces(String code, int idPoubelle) {
        String sql = "INSERT INTO codesacces (code, id_poubelle) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, code);
            ps.setInt(2, idPoubelle);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'insertion du code d'accès : " + e.getMessage(), e);
        }
    }

    public boolean verifierCodeAcces(String code) {
        String sql = "SELECT 1 FROM codesacces WHERE code = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, code);
            ResultSet rs = ps.executeQuery();
            return rs.next();

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la vérification du code d'accès : " + e.getMessage(), e);
        }
    }

    public int getIdPoubelleByCode(String code) {
        String sql = "SELECT id_poubelle FROM codesacces WHERE code = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, code);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt("id_poubelle");
            } else {
                throw new RuntimeException("Aucune poubelle trouvée pour le code : " + code);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération de l'id de la poubelle : " + e.getMessage(), e);
        }
    }

    public void updateCodeAcces(int idPoubelle, String newCode) {
        String sql = "UPDATE codesacces SET code = ? WHERE id_poubelle = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, newCode);
            ps.setInt(2, idPoubelle);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la mise à jour du code d'accès : " + e.getMessage(), e);
        }
    }

    public void deleteCodeAcces(int idPoubelle) {
        String sql = "DELETE FROM codesacces WHERE id_poubelle = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idPoubelle);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression du code d'accès : " + e.getMessage(), e);
        }
    }
}

