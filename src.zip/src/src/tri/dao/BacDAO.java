package src.tri.dao;

import java.sql.*;
import java.util.*;
import src.tri.logic.Bac;
import src.tri.logic.TypeDechet;
import src.tri.utils.DatabaseConnection;

public class BacDAO {

	private final Map<Integer, Bac> cacheBacs = new HashMap<>();

	public void insertBac(Bac bac, int idPoubelleIntelligente) {
	    String sql = "INSERT INTO bac (poidsActuel, capaciteMax, typeDechetBac, idPoubelleIntelligente) VALUES (?, ?, ?, ?)";

	    try (Connection conn = DatabaseConnection.getConnection();
	         PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

	        String typesDechets = String.join(",",
	                bac.getTypesDechets().stream().map(TypeDechet::name).toArray(String[]::new));

	        ps.setInt(1, bac.getPoidsActuel());
	        ps.setInt(2, bac.getCapaciteMax());
	        ps.setString(3, typesDechets);
	        ps.setInt(4, idPoubelleIntelligente);

	        ps.executeUpdate();

	        try (ResultSet rs = ps.getGeneratedKeys()) {
	            if (rs.next()) {
	                bac.setIdBac(rs.getInt(1));
	                cacheBacs.put(bac.getIdBac(), bac);
	            } else {
	                throw new RuntimeException("Échec lors de la récupération de l'ID généré pour le bac.");
	            }
	        }

	    } catch (SQLException e) {
	        throw new RuntimeException("Erreur lors de l'insertion du bac : " + e.getMessage(), e);
	    }
	}


	public Bac getBacById(int idBac) {
		if (cacheBacs.containsKey(idBac)) {
			return cacheBacs.get(idBac);
		}

		try (Connection conn = DatabaseConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement("SELECT * FROM bac WHERE idBac = ?")) {

			ps.setInt(1, idBac);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				String typesDechetsStr = rs.getString("typeDechet");
				List<TypeDechet> typesDechets = new ArrayList<>();
				for (String type : typesDechetsStr.split(",")) {
					typesDechets.add(TypeDechet.valueOf(type.trim()));
				}

				Bac bac = new Bac(rs.getInt("capaciteMax"), typesDechets);
				bac.setIdBac(idBac);
				bac.setPoidsActuel(rs.getInt("poidsActuel"));

				cacheBacs.put(idBac, bac);
				return bac;
			} else {
				throw new RuntimeException("Aucun bac trouvé avec l'id " + idBac);
			}

		} catch (SQLException e) {
			throw new RuntimeException("Erreur lors de la récupération du bac : " + e.getMessage(), e);
		}
	}

	public void updatePoidsActuel(int idBac, int nouveauPoids) {
		try (Connection conn = DatabaseConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement("UPDATE bac SET poidsActuel = ? WHERE idBac = ?")) {

			ps.setInt(1, nouveauPoids);
			ps.setInt(2, idBac);
			ps.executeUpdate();

			// mettre à jour dans le cache aussi
			Bac bac = cacheBacs.get(idBac);
			if (bac != null) {
				bac.setPoidsActuel(nouveauPoids);
			}

		} catch (SQLException e) {
			throw new RuntimeException("Erreur lors de la mise à jour du poids du bac : " + e.getMessage(), e);
		}
	}

	public void deleteBac(int idBac) {
		try (Connection conn = DatabaseConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement("DELETE FROM bac WHERE idBac = ?")) {

			ps.setInt(1, idBac);
			ps.executeUpdate();

			cacheBacs.remove(idBac); // nettoyage du cache

		} catch (SQLException e) {
			throw new RuntimeException("Erreur lors de la suppression du bac : " + e.getMessage(), e);
		}
	}

	public List<Bac> getBacsByPoubelle(int idPoubelleIntelligente) {
		List<Bac> bacs = new ArrayList<>();

		try (Connection conn = DatabaseConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement("SELECT * FROM bac WHERE idPoubelleIntelligente = ?")) {

			ps.setInt(1, idPoubelleIntelligente);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				int idBac = rs.getInt("idBac");

				if (cacheBacs.containsKey(idBac)) {
					bacs.add(cacheBacs.get(idBac));
					continue;
				}

				String typesDechetsStr = rs.getString("typeDechet");
				List<TypeDechet> typesDechets = new ArrayList<>();
				for (String type : typesDechetsStr.split(",")) {
					typesDechets.add(TypeDechet.valueOf(type.trim()));
				}

				Bac bac = new Bac(rs.getInt("capaciteMax"), typesDechets);
				bac.setIdBac(idBac);
				bac.setPoidsActuel(rs.getInt("poidsActuel"));

				cacheBacs.put(idBac, bac);
				bacs.add(bac);
			}

		} catch (SQLException e) {
			throw new RuntimeException("Erreur lors de la récupération des bacs : " + e.getMessage(), e);
		}

		return bacs;
	}

	public void clearCache() {
		cacheBacs.clear();
	}
	
	public void viderBac(int idBac) {
        String sql = "UPDATE bac SET poidsActuel = 0 WHERE idBac = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idBac);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
