package src.tri.dao;

import java.sql.*;
import java.util.*;

import src.tri.logic.BonAchat;
import src.tri.utils.DatabaseConnection;

public class BonAchatDAO {

    private final Map<Integer, BonAchat> cacheBonAchats = new HashMap<>();

    public void insertBonAchat(BonAchat bonAchat) {
        String sql = "INSERT INTO bonachat (montant) VALUES (?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, bonAchat.getMontant());
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    bonAchat.setId(rs.getInt(1));
                    cacheBonAchats.put(bonAchat.getId(), bonAchat); // mise en cache
                } else {
                    throw new RuntimeException("Échec de la récupération de l'ID généré pour le bon d'achat.");
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'insertion du bon d'achat : " + e.getMessage(), e);
        }
    }

    public BonAchat getBonAchatById(int idBonAchat) {
        if (cacheBonAchats.containsKey(idBonAchat)) {
            return cacheBonAchats.get(idBonAchat);
        }

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM bonachat WHERE idBonAchat = ?")) {

            ps.setInt(1, idBonAchat);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                BonAchat bon = new BonAchat(
                        rs.getInt("idBonAchat"),
                        rs.getInt("montant")
                );
                cacheBonAchats.put(idBonAchat, bon); // mise en cache
                return bon;
            } else {
                throw new RuntimeException("Aucun bon d'achat trouvé avec l'id " + idBonAchat);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération du bon d'achat : " + e.getMessage(), e);
        }
    }

    public void deleteBonAchat(int idBonAchat) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM bonachat WHERE idBonAchat = ?")) {

            ps.setInt(1, idBonAchat);
            ps.executeUpdate();

            cacheBonAchats.remove(idBonAchat); // suppression du cache

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression du bon d'achat : " + e.getMessage(), e);
        }
    }

    public List<BonAchat> getAllBonAchats() {
        List<BonAchat> bons = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM bonachat")) {

            while (rs.next()) {
                int id = rs.getInt("idBonAchat");

                if (cacheBonAchats.containsKey(id)) {
                    bons.add(cacheBonAchats.get(id));
                    continue;
                }

                BonAchat bon = new BonAchat(
                        id,
                        rs.getInt("montant")
                );
                cacheBonAchats.put(id, bon);
                bons.add(bon);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération des bons d'achat : " + e.getMessage(), e);
        }

        return bons;
    }

    public void clearCache() {
        cacheBonAchats.clear();
    }
}

