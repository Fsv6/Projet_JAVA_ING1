package src.tri.dao;

import java.sql.*;
import java.util.*;

import src.tri.logic.Dechet;
import src.tri.logic.TypeDechet;
import src.tri.utils.DatabaseConnection;

public class DechetDAO {

    private final Map<Integer, Dechet> cacheDechets = new HashMap<>();

    public void insertDechet(Dechet dechet, int idDepot) {
        String sql = "INSERT INTO dechet (typeDechet, poids, idDepot) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, dechet.getType().name());
            ps.setInt(2, dechet.getPoids());
            ps.setInt(3, idDepot);
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    dechet.setIdDechet(rs.getInt(1));
                    cacheDechets.put(dechet.getIdDechet(), dechet);
                } else {
                    throw new RuntimeException("Échec de la récupération de l'ID généré pour le déchet.");
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'insertion du déchet : " + e.getMessage(), e);
        }
    }

    public Dechet getDechetById(int idDechet) {
        if (cacheDechets.containsKey(idDechet)) {
            return cacheDechets.get(idDechet);
        }

        String sql = "SELECT * FROM dechet WHERE idDechet = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idDechet);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Dechet dechet = new Dechet(
                        rs.getInt("idDechet"),
                        TypeDechet.valueOf(rs.getString("typeDechet")),
                        rs.getInt("poids")
                );
                cacheDechets.put(dechet.getIdDechet(), dechet);
                return dechet;
            } else {
                throw new RuntimeException("Aucun déchet trouvé avec l'id " + idDechet);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération du déchet : " + e.getMessage(), e);
        }
    }

    public List<Dechet> getDechetsByDepot(int idDepot) {
        List<Dechet> dechets = new ArrayList<>();
        String sql = "SELECT * FROM dechet WHERE idDepot = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idDepot);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int idDechet = rs.getInt("idDechet");

                Dechet dechet;
                if (cacheDechets.containsKey(idDechet)) {
                    dechet = cacheDechets.get(idDechet);
                } else {
                    dechet = new Dechet(
                            idDechet,
                            TypeDechet.valueOf(rs.getString("typeDechet")),
                            rs.getInt("poids")
                    );
                    cacheDechets.put(idDechet, dechet);
                }

                dechets.add(dechet);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération des déchets : " + e.getMessage(), e);
        }

        return dechets;
    }

    public void deleteDechet(int idDechet) {
        String sql = "DELETE FROM dechet WHERE idDechet = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idDechet);
            ps.executeUpdate();
            cacheDechets.remove(idDechet);

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression du déchet : " + e.getMessage(), e);
        }
    }

    public void clearCache() {
        cacheDechets.clear();
    }
}

