package src.tri.dao;

import java.sql.*;
import java.util.*;

import src.tri.logic.Depot;
import src.tri.logic.Dechet;
import src.tri.utils.DatabaseConnection;

public class DepotDAO {

    private final Map<Integer, Depot> cacheDepots = new HashMap<>();

    public void insertDepot(Depot depot, int idCompte, int idPoubelleIntelligente) {
        String sql = "INSERT INTO depot (poidsDechet, pointsAttribues, dateDepot, idCompte, idPoubelleIntelligente) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            java.sql.Date sqlDateDepot = new java.sql.Date(depot.getDateDepot().getTime());

            // poidsDechet n'existe pas dans l'objet mais dans la table : on le recalcule éventuellement
            int poidsDechet = depot.getListeDechet().stream().mapToInt(Dechet::getPoids).sum();

            ps.setInt(1, poidsDechet);
            ps.setInt(2, depot.getPointsAttribues());
            ps.setDate(3, sqlDateDepot);
            ps.setInt(4, idCompte);
            ps.setInt(5, idPoubelleIntelligente);

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    depot.setIdDepot(rs.getInt(1));
                    cacheDepots.put(depot.getIdDepot(), depot);
                } else {
                    throw new RuntimeException("Échec de la récupération de l'ID généré pour le dépôt.");
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'insertion du dépôt : " + e.getMessage(), e);
        }
    }

    public Depot getDepotById(int idDepot) {
        if (cacheDepots.containsKey(idDepot)) {
            return cacheDepots.get(idDepot);
        }

        String sql = "SELECT * FROM depot WHERE idDepot = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idDepot);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Depot depot = new Depot(
                        idDepot,
                        rs.getInt("pointsAttribues"),
                        rs.getDate("dateDepot"),
                        new ArrayList<>() // on ne récupère pas les déchets ici
                );

                cacheDepots.put(idDepot, depot);
                return depot;
            } else {
                throw new RuntimeException("Aucun dépôt trouvé avec l'id " + idDepot);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération du dépôt : " + e.getMessage(), e);
        }
    }

    public void deleteDepot(int idDepot) {
        String sql = "DELETE FROM depot WHERE idDepot = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idDepot);
            ps.executeUpdate();
            cacheDepots.remove(idDepot);

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression du dépôt : " + e.getMessage(), e);
        }
    }

    public List<Depot> getDepotsByCompte(int idCompte) {
        List<Depot> depots = new ArrayList<>();
        String sql = "SELECT * FROM depot WHERE idCompte = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idCompte);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int idDepot = rs.getInt("idDepot");

                Depot depot;
                if (cacheDepots.containsKey(idDepot)) {
                    depot = cacheDepots.get(idDepot);
                } else {
                    depot = new Depot(
                            idDepot,
                            rs.getInt("pointsAttribues"),
                            rs.getDate("dateDepot"),
                            new ArrayList<>() // liste vide pour l'instant
                    );
                    cacheDepots.put(idDepot, depot);
                }

                depots.add(depot);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération des dépôts du compte : " + e.getMessage(), e);
        }

        return depots;
    }

    public void clearCache() {
        cacheDepots.clear();
    }
}


