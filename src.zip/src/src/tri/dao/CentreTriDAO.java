package src.tri.dao;

import java.sql.*;
import src.tri.logic.CentreTri;
import src.tri.utils.DatabaseConnection;

public class CentreTriDAO {

    private CentreTri cacheCentre = null;

    public void insertCentreTri(CentreTri centreTri) {
        String sql = "INSERT INTO centretri (nomCentreTri, numRue, nomRue, ville, codePostal) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, centreTri.getNomCentreTri());
            ps.setInt(2, centreTri.getNumRue());
            ps.setString(3, centreTri.getNomRue());
            ps.setString(4, centreTri.getVille());
            ps.setInt(5, centreTri.getCodePostal());

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    centreTri.setIdCentreTri(rs.getInt(1));
                    this.cacheCentre = centreTri;
                } else {
                    throw new RuntimeException("Échec de récupération de l'ID généré pour le centre de tri.");
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'insertion du centre de tri : " + e.getMessage(), e);
        }
    }

    public CentreTri getUniqueCentreTri() {
        if (cacheCentre != null) {
            return cacheCentre;
        }

        String sql = "SELECT * FROM centretri LIMIT 1";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            if (rs.next()) {
                cacheCentre = new CentreTri(
                        rs.getInt("idCentreTri"),
                        rs.getString("nomCentreTri"),
                        rs.getInt("numRue"),
                        rs.getString("nomRue"),
                        rs.getString("ville"),
                        rs.getInt("codePostal")
                );
                return cacheCentre;
            } else {
                throw new RuntimeException("Aucun centre de tri trouvé en base.");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération du centre de tri : " + e.getMessage(), e);
        }
    }
    public int getUniqueCentreTriId() {
        String sql = "SELECT idCentreTri FROM centretri LIMIT 1";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("idCentreTri");
            } else {
                throw new RuntimeException("Aucun centre de tri trouvé dans la base.");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération de l'ID du centre de tri : " + e.getMessage(), e);
        }
    }


}

