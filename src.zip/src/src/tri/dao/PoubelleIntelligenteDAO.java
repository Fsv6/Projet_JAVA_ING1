package src.tri.dao;

import java.sql.*;
import java.util.*;

import src.tri.logic.PoubelleIntelligente;
import src.tri.utils.DatabaseConnection;

public class PoubelleIntelligenteDAO {

    private final Map<Integer, PoubelleIntelligente> cachePoubelles = new HashMap<>();

    public void insertPoubelle(PoubelleIntelligente poubelle, int idCentreTri) {
        String sql = "INSERT INTO poubelleintelligente (nomQuartier, longitudeEmplacement, latitudeEmplacement, idCentreTri) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, poubelle.getNomQuartier());
            ps.setFloat(2, poubelle.getLongitudeEmplacement());
            ps.setFloat(3, poubelle.getLatitudeEmplacement());
            ps.setInt(4, idCentreTri);

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    poubelle.setId(rs.getInt(1));
                    cachePoubelles.put(poubelle.getId(), poubelle);
                } else {
                    throw new RuntimeException("Échec de la récupération de l'ID généré pour la poubelle.");
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'insertion de la poubelle intelligente : " + e.getMessage(), e);
        }
    }

    public PoubelleIntelligente getPoubelleById(int idPoubelleIntelligente) {
        if (cachePoubelles.containsKey(idPoubelleIntelligente)) {
            return cachePoubelles.get(idPoubelleIntelligente);
        }

        String sql = "SELECT * FROM poubelleintelligente WHERE idPoubelleIntelligente = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idPoubelleIntelligente);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                PoubelleIntelligente poubelle = new PoubelleIntelligente(
                        rs.getInt("idPoubelleIntelligente"),
                        rs.getString("nomQuartier"),
                        rs.getFloat("latitudeEmplacement"),
                        rs.getFloat("longitudeEmplacement")
                );
                cachePoubelles.put(poubelle.getId(), poubelle);
                return poubelle;
            } else {
                throw new RuntimeException("Aucune poubelle trouvée avec l'id " + idPoubelleIntelligente);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération de la poubelle : " + e.getMessage(), e);
        }
    }

    public void deletePoubelle(int idPoubelleIntelligente) {
        String sql = "DELETE FROM poubelleintelligente WHERE idPoubelleIntelligente = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idPoubelleIntelligente);
            ps.executeUpdate();
            cachePoubelles.remove(idPoubelleIntelligente);

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression de la poubelle intelligente : " + e.getMessage(), e);
        }
    }

    public void clearCache() {
        cachePoubelles.clear();
    }
    
    public List<PoubelleIntelligente> getAllPoubelles() {
        List<PoubelleIntelligente> poubelles = new ArrayList<>();
        String sql = "SELECT * FROM poubelleintelligente";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("idPoubelleIntelligente");

                // Si déjà en cache, on réutilise
                if (cachePoubelles.containsKey(id)) {
                    poubelles.add(cachePoubelles.get(id));
                    continue;
                }

                // Sinon, on instancie et on met en cache
                PoubelleIntelligente poubelle = new PoubelleIntelligente(
                        id,
                        rs.getString("nomQuartier"),
                        rs.getFloat("latitudeEmplacement"),
                        rs.getFloat("longitudeEmplacement")
                );
                cachePoubelles.put(id, poubelle);
                poubelles.add(poubelle);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération des poubelles : " + e.getMessage(), e);
        }

        return poubelles;
    }

}
