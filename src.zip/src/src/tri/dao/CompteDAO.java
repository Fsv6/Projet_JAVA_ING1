package src.tri.dao;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

import src.tri.logic.Compte;
import src.tri.utils.DatabaseConnection;

public class CompteDAO {

    private final Map<Integer, Compte> cacheComptes = new HashMap<>();

    public void insertCompte(Compte compte) {
        String sql = "INSERT INTO compte (nomResponsable, prenomResponsable, nbPointsFidelite) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, compte.getNom());
            ps.setString(2, compte.getPrenom());
            ps.setInt(3, compte.getNbPointsFidelite());

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    compte.setId(rs.getInt(1));
                    cacheComptes.put(compte.getId(), compte); // mise en cache
                } else {
                    throw new RuntimeException("Échec de la récupération de l'ID généré pour le compte.");
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'insertion du compte : " + e.getMessage(), e);
        }
    }

    public Compte getCompteById(int idCompte) {
        if (cacheComptes.containsKey(idCompte)) {
            return cacheComptes.get(idCompte);
        }

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM compte WHERE idCompte = ?")) {

            ps.setInt(1, idCompte);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Compte compte = new Compte(
                        rs.getInt("idCompte"),
                        rs.getString("nomResponsable"),
                        rs.getString("prenomResponsable"),
                        rs.getInt("nbPointsFidelite")
                );
                cacheComptes.put(idCompte, compte); // mise en cache
                return compte;
            } else {
                throw new RuntimeException("Aucun compte trouvé avec l'id " + idCompte);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération du compte : " + e.getMessage(), e);
        }
    }

    public void updatePointsFidelite(int idCompte, int nouveauxPoints) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE compte SET nbPointsFidelite = ? WHERE idCompte = ?")) {

            ps.setInt(1, nouveauxPoints);
            ps.setInt(2, idCompte);
            ps.executeUpdate();

            Compte compte = cacheComptes.get(idCompte);
            if (compte != null) {
                compte.setNbPointsFidelite(nouveauxPoints);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la mise à jour des points de fidélité : " + e.getMessage(), e);
        }
    }

    public void deleteCompte(int idCompte) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM compte WHERE idCompte = ?")) {

            ps.setInt(1, idCompte);
            ps.executeUpdate();

            cacheComptes.remove(idCompte);

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression du compte : " + e.getMessage(), e);
        }
    }

    public void clearCache() {
        cacheComptes.clear();
    }
}

