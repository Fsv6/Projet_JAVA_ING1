package src.tri.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import src.tri.logic.Commerce;
import src.tri.utils.DatabaseConnection;

public class CommerceDAO {

    private final Map<Integer, Commerce> cacheCommerces = new HashMap<>();

    public void insertCommerce(Commerce commerce) {
        String sql = "INSERT INTO commerce (nom) VALUES (?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, commerce.getNom());
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    commerce.setIdCommerce(rs.getInt(1));
                    cacheCommerces.put(commerce.getIdCommerce(), commerce);
                } else {
                    throw new RuntimeException("Échec de la récupération de l'ID généré pour le commerce.");
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'insertion du commerce : " + e.getMessage(), e);
        }
    }

    public Commerce getCommerceById(int idCommerce) {
        if (cacheCommerces.containsKey(idCommerce)) {
            return cacheCommerces.get(idCommerce);
        }

        String sql = "SELECT * FROM commerce WHERE idCommerce = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idCommerce);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Commerce commerce = new Commerce(
                        rs.getInt("idCommerce"),
                        rs.getString("nom")
                );
                cacheCommerces.put(idCommerce, commerce);
                return commerce;
            } else {
                throw new RuntimeException("Aucun commerce trouvé avec l'id " + idCommerce);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération du commerce : " + e.getMessage(), e);
        }
    }

    public void deleteCommerce(int idCommerce) {
        String sql = "DELETE FROM commerce WHERE idCommerce = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idCommerce);
            ps.executeUpdate();
            cacheCommerces.remove(idCommerce);

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression du commerce : " + e.getMessage(), e);
        }
    }

    public void clearCache() {
        cacheCommerces.clear();
    }
    
    public List<Integer> getAllCommerceIds() {
        List<Integer> ids = new ArrayList<>();
        String sql = "SELECT idCommerce FROM commerce";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                ids.add(rs.getInt("idCommerce"));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération des IDs de commerce : " + e.getMessage(), e);
        }

        return ids;
    }

}

