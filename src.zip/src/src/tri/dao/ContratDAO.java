package src.tri.dao;

import java.sql.*;
import java.sql.Date;
import java.util.*;
import src.tri.logic.Contrat;
import src.tri.utils.DatabaseConnection;

public class ContratDAO {

    private final Map<String, Contrat> cacheContrats = new HashMap<>();

    private String cacheKey(int idCentreTri, int idCommerce) {
        return idCentreTri + "-" + idCommerce;
    }

    public void insertContrat(Contrat contrat, int idCentreTri, int idCommerce) {
        String sql = "INSERT INTO contrat (idCentreTri, idCommerce, dateDebutContrat, dateFinContrat, listeCatProduits) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            String listeCategories = String.join(",", contrat.getListeCatProduits());

            ps.setInt(1, idCentreTri);
            ps.setInt(2, idCommerce);
            ps.setDate(3, Date.valueOf(contrat.getDateDebut()));
            ps.setDate(4, Date.valueOf(contrat.getDateFin()));
            ps.setString(5, listeCategories);

            ps.executeUpdate();

            // Pas de getGeneratedKeys ici : la clé est composée et connue
            cacheContrats.put(idCentreTri + "-" + idCommerce, contrat);

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'insertion du contrat : " + e.getMessage(), e);
        }
    }


    public Contrat getContrat(int idCentreTri, int idCommerce) {
        String key = cacheKey(idCentreTri, idCommerce);
        if (cacheContrats.containsKey(key)) {
            return cacheContrats.get(key);
        }

        String sql = "SELECT * FROM contrat WHERE idCentreTri = ? AND idCommerce = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idCentreTri);
            ps.setInt(2, idCommerce);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                List<String> listeCatProduits = Arrays.asList(rs.getString("listeCatProduits").split(","));
                Contrat contrat = new Contrat(
                        rs.getDate("dateDebutContrat").toLocalDate(),
                        rs.getDate("dateFinContrat").toLocalDate(),
                        listeCatProduits
                );
                contrat.setId(rs.getInt("idContrat"));
                cacheContrats.put(key, contrat);
                return contrat;
            } else {
                throw new RuntimeException("Aucun contrat trouvé pour idCentreTri=" + idCentreTri + " et idCommerce=" + idCommerce);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération du contrat : " + e.getMessage(), e);
        }
    }

    public void deleteContrat(int idCentreTri, int idCommerce) {
        String sql = "DELETE FROM contrat WHERE idCentreTri = ? AND idCommerce = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idCentreTri);
            ps.setInt(2, idCommerce);
            ps.executeUpdate();
            cacheContrats.remove(cacheKey(idCentreTri, idCommerce));

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression du contrat : " + e.getMessage(), e);
        }
    }

    public void clearCache() {
        cacheContrats.clear();
    }
    
    public List<Contrat> getAllContrats() {
        List<Contrat> contrats = new ArrayList<>();
        String sql = "SELECT * FROM contrat";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int idCentreTri = rs.getInt("idCentreTri");
                int idCommerce = rs.getInt("idCommerce");
                String key = cacheKey(idCentreTri, idCommerce);

                // Si déjà en cache, on réutilise l'objet existant
                if (cacheContrats.containsKey(key)) {
                    contrats.add(cacheContrats.get(key));
                    continue;
                }

                // Sinon, on crée et on ajoute au cache
                List<String> listeCatProduits = Arrays.asList(rs.getString("listeCatProduits").split(","));
                Contrat contrat = new Contrat(
                        rs.getDate("dateDebutContrat").toLocalDate(),
                        rs.getDate("dateFinContrat").toLocalDate(),
                        listeCatProduits
                );
                contrat.setId(rs.getInt("idContrat"));

                cacheContrats.put(key, contrat);
                contrats.add(contrat);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération de tous les contrats : " + e.getMessage(), e);
        }

        return contrats;
    }

    
    
}

