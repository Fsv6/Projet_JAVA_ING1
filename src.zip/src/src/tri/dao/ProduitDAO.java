package src.tri.dao;

import java.sql.*;
import java.util.*;

import src.tri.logic.Produit;
import src.tri.utils.DatabaseConnection;

public class ProduitDAO {

    private final Map<Integer, Produit> cacheProduits = new HashMap<>();

    public void insertProduit(Produit produit) {
        String sql = "INSERT INTO produit (nomProduit, categorie, prix) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, produit.getNom());
            ps.setString(2, produit.getCategorie());
            ps.setDouble(3, produit.getPrix());

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    produit.setIdProduit(rs.getInt(1));
                    cacheProduits.put(produit.getIdProduit(), produit);
                } else {
                    throw new RuntimeException("Échec de la récupération de l'ID généré pour le produit.");
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'insertion du produit : " + e.getMessage(), e);
        }
    }

    public Produit getProduitById(int idProduit) {
        if (cacheProduits.containsKey(idProduit)) {
            return cacheProduits.get(idProduit);
        }

        String sql = "SELECT * FROM produit WHERE idProduit = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idProduit);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Produit produit = new Produit(
                        rs.getInt("idProduit"),
                        rs.getString("categorie"),
                        rs.getString("nomProduit"),
                        rs.getDouble("prix")
                );
                cacheProduits.put(produit.getIdProduit(), produit);
                return produit;
            } else {
                throw new RuntimeException("Aucun produit trouvé avec l'id " + idProduit);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération du produit : " + e.getMessage(), e);
        }
    }

    public void deleteProduit(int idProduit) {
        String sql = "DELETE FROM produit WHERE idProduit = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idProduit);
            ps.executeUpdate();
            cacheProduits.remove(idProduit);

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression du produit : " + e.getMessage(), e);
        }
    }

    public void clearCache() {
        cacheProduits.clear();
    }
}

