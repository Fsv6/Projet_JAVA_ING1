package src.tri.main;

import src.tri.dao.*;
import src.tri.exception.DechetNonConformeException;
import src.tri.logic.*;
import java.util.*;

public class MainTest {

    private CentreTriDAO centreDAO;
    private PoubelleIntelligenteDAO poubelleDAO;
    private BacDAO bacDAO;
    private CommerceDAO commerceDAO;
    private CompteDAO compteDAO;
    private BonAchatDAO bonAchatDAO;
    private ProduitDAO produitDAO;
    private VendreDAO vendreDAO;
    private DechetDAO dechetDAO;
    private DepotDAO depotDAO;
    private ContratDAO contratDAO;

    private CentreTri centreTri;
    private Commerce commerce;

    public void initialiserDAOs() {
        centreDAO = new CentreTriDAO();
        poubelleDAO = new PoubelleIntelligenteDAO();
        bacDAO = new BacDAO();
        commerceDAO = new CommerceDAO();
        compteDAO = new CompteDAO();
        bonAchatDAO = new BonAchatDAO();
        produitDAO = new ProduitDAO();
        vendreDAO = new VendreDAO();
        dechetDAO = new DechetDAO();
        depotDAO = new DepotDAO();
        contratDAO = new ContratDAO();
    }

    public void initialiserDonneesGlobales() {
        centreTri = new CentreTri("Cy TECH", 1, "Chemin des Paradis", "Cergy", 95000);
        centreDAO.insertCentreTri(centreTri);

        commerce = new Commerce("Supermarché Bio");
        commerceDAO.insertCommerce(commerce);
    }

    public void testConversionPointsEnBon() {
        System.out.println("\n[Test] Conversion progressive de deux bons d'achat");

        Compte compte = new Compte("Jean", "Dupont", 130);
        compteDAO.insertCompte(compte);

        compte.convertirEnBonAchat();
        BonAchat bon1 = compte.getListBonAchat().get(0);
        bonAchatDAO.insertBonAchat(bon1);

        compteDAO.updatePointsFidelite(compte.getId(), compte.getNbPointsFidelite());

        compte.convertirEnBonAchat();
        BonAchat bon2 = compte.getListBonAchat().get(1);
        bonAchatDAO.insertBonAchat(bon2);

        Compte compteFinal = compteDAO.getCompteById(compte.getId());
        if (compteFinal.getNbPointsFidelite() == 10) {
            System.out.println("Test réussi : le compte a bien 10 points restants.");
        } else {
            System.out.println("Erreur : points attendus = 10, obtenus = " + compteFinal.getNbPointsFidelite());
        }
    }

    public void testDepotConforme() {
        System.out.println("\n[Test] Dépôt conforme");

        Compte compte = new Compte("Paul", "Durand", 0);
        compteDAO.insertCompte(compte);

        PoubelleIntelligente poubelle = new PoubelleIntelligente("Quartier Test", 48.85f, 2.35f);
        poubelleDAO.insertPoubelle(poubelle, centreTri.getIdCentreTri());

        Bac bac = new Bac(100, List.of(TypeDechet.PAPIER));
        bacDAO.insertBac(bac, poubelle.getId());
        poubelle.ajouterBac(bac);

        Dechet papier = new Dechet(TypeDechet.PAPIER, 1);
        ArrayList<Dechet> dechets = new ArrayList<>();
        dechets.add(papier);
        Depot depot = new Depot(0, new Date(), dechets);

        poubelle.ajouterDepot(depot, bac);
        System.out.println("Points attribués : " + depot.getPointsAttribues());
    }

    public void testDepotNonConforme() {
        System.out.println("\n[Test] Dépôt non conforme");

        Compte compte = new Compte("Lucie", "Martin", 0);
        compteDAO.insertCompte(compte);

        PoubelleIntelligente poubelle = new PoubelleIntelligente("Quartier Erreur", 48.86f, 2.34f);
        poubelleDAO.insertPoubelle(poubelle, centreTri.getIdCentreTri());

        Bac bac = new Bac(100, List.of(TypeDechet.VERRE));
        bacDAO.insertBac(bac, poubelle.getId());
        poubelle.ajouterBac(bac);

        Dechet plastique = new Dechet(TypeDechet.PLASTIQUE, 1);
        ArrayList<Dechet> dechets = new ArrayList<>();
        dechets.add(plastique);
        Depot depot = new Depot(0, new Date(), dechets);

        try {
            poubelle.ajouterDepot(depot, bac);
            System.out.println("Erreur : le dépôt aurait dû échouer.");
        } catch (DechetNonConformeException e) {
            System.out.println("Exception capturée (attendue). Points attribués : " + depot.getPointsAttribues());
        }
    }

    public static void main(String[] args) {
        System.out.println("=== Début des tests ===");

        MainTest test = new MainTest();
        test.initialiserDAOs();
        test.initialiserDonneesGlobales();

        test.testConversionPointsEnBon();
        test.testDepotConforme();
        test.testDepotNonConforme();

        System.out.println("=== Fin des tests ===");
    }
} 



