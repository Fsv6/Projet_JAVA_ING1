package src.tri.exception;

public class BacPleinException extends RuntimeException {
    public BacPleinException(String message) {
        super(message);
    }
}
