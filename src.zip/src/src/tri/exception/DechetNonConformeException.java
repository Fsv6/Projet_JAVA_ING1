package src.tri.exception;

public class DechetNonConformeException extends RuntimeException {
    public DechetNonConformeException(String message) {
        super(message);
    }
}
